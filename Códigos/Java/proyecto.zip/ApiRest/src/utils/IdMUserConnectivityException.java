package utils;

public class IdMUserConnectivityException extends IdMUserException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public IdMUserConnectivityException(String message){
		super(message);
	}
}
