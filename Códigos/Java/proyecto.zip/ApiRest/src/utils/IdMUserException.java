package utils;

public class IdMUserException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public IdMUserException(String message){
		super(message);
	}
}
