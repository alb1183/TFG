package utils;

public enum HttpVerbs {
GET, POST, PUT, DELETE
}
