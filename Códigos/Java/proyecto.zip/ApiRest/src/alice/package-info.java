/**
 * Alice provides AES encryption and decryption methods for byte arrays and files. It's configurable to support a
 * variety of different key derivation functions and message authentication specifications.
 */
package alice;